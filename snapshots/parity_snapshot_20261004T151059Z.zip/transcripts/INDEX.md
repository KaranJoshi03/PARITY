# Transcript index
How to read: one folder per phase task. Below, the moments that mattered most.
| # | Phase | What happened | Type (bluff caught / design overridden / recovery / pushback) | Link |